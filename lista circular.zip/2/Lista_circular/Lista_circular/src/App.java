import java.awt.*;
import javax.swing.*;

public class App extends JPanel { 
    private Nodo actual; 
    private Timer timer; 

    public App() {
        actual = new Nodo(200, 200); 

        timer = new Timer(500, e -> { 
            actual.x += 10; 
            if (actual.x > 400) actual.x = 0; 
            repaint(); 
        });
        timer.start(); 
    }

    @Override
    protected void paintComponent(Graphics g) { 
        super.paintComponent(g); 
        g.setColor(Color.GREEN); 
        g.fillOval(actual.x, actual.y, 10, 10); 
    }

    public static void main(String[] args) { 
        JFrame frame = new JFrame();
        frame.add(new App()); 
        frame.setSize(500, 500); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        frame.setVisible(true); 
    }
}

class Nodo { 
    int x, y; 
    Nodo(int x, int y) { 
        this.x = x; 
        this.y = y; 
    }
}
